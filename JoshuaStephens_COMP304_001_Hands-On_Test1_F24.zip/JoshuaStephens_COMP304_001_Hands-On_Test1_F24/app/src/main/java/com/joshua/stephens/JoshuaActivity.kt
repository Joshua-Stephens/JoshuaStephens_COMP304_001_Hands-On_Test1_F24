//Student number: 301215503
package com.joshua.stephens

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Icon
import androidx.compose.foundation.Image
import androidx.compose.material3.*
import com.joshua.stephens.ui.theme.MyContactsTheme


class JoshuaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyContactsTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current

    TopAppBar(
        title = { Text(text = "MyContacts") },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Yellow
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Image(
            painter = painterResource(id = R.drawable.ic_bird_company_logo),
            contentDescription = "App Logo",
            modifier = Modifier
                .size(600.dp)
                .padding(bottom = 20.dp)
        )

        Button(
            onClick = {
                context.startActivity(Intent(context, StephensActivity::class.java))
            },
            enabled = true,
            shape = androidx.compose.material3.MaterialTheme.shapes.large,
            colors = ButtonDefaults.buttonColors(),
        ) {

            Icon(
                painter = painterResource(id = R.drawable.ic_add_contact_image),
                contentDescription = "Manage Contacts",
                modifier = Modifier.size(48.dp)
            )
        }
    }
}
