//Student number: 301215503
package com.joshua.stephens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.compose.material3.RadioButton
import com.joshua.stephens.ui.theme.MyContactsTheme

class StephensActivity : ComponentActivity() {

    // ViewModel for managing contact data
    private val contactViewModel: ContactViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyContactsTheme {
                ContactForm(contactViewModel)
            }
        }
    }

    // ViewModel for managing the list of contacts
    class ContactViewModel : ViewModel() {
        val contacts = mutableStateListOf<Contact>()

        fun addContact(name: String, phone: String, email: String, type: String) {
            contacts.add(Contact(name, phone, email, type))
        }
    }

    // Data class for Contact
    data class Contact(val name: String, val phone: String, val email: String, val type: String)


    @Composable
    fun ContactForm(viewModel: ContactViewModel) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var contactType by remember { mutableStateOf(setOf<String>()) }

        // Create SnackbarHostState
        val snackbarHostState = remember { SnackbarHostState() }

        // State to control when to show Snackbar
        var showSnackbar by remember { mutableStateOf(false) }
        var snackbarMessage by remember { mutableStateOf("") }

        // Scaffold to manage Snackbar
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { paddingValues ->

            Column(modifier = Modifier
                .padding(16.dp)
                .padding(paddingValues)) {
                Text(text = "Add Contact", style = MaterialTheme.typography.headlineMedium)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Contact Type Selection: Checkbox or RadioButton based on the first letter of the name
                Text(text = "Contact Type")
                if (name.firstOrNull()?.uppercaseChar() in 'A'..'N') {
                    CheckboxSelection(contactType, onSelection = { contactType = it })
                } else {
                    RadioButtonSelection(contactType.firstOrNull() ?: "", onSelection = { contactType = setOf(it) })
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        // Add contact
                        viewModel.addContact(name, phone, email, contactType.joinToString(", "))
                        // Prepare to show Snackbar
                        snackbarMessage = "Added: $name, Phone: $phone, Email: $email, Type: ${contactType.joinToString(", ")}"
                        showSnackbar = true // Trigger Snackbar visibility
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "Add Contact")
                }

                // Show Snackbar
                if (showSnackbar) {
                    LaunchedEffect(snackbarHostState) {
                        snackbarHostState.showSnackbar(snackbarMessage)
                        showSnackbar = false // Reset the trigger after showing
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn {
                    items(viewModel.contacts) { contact ->
                        Text(text = "Name: ${contact.name}, Phone: ${contact.phone}, Email: ${contact.email}, Type: ${contact.type}")
                    }
                }
            }
        }
    }

    @Composable
    fun CheckboxSelection(selectedTypes: Set<String>, onSelection: (Set<String>) -> Unit) {
        Row {
            Checkbox(
                checked = selectedTypes.contains("Friend"),
                onCheckedChange = { isChecked ->
                    val updatedSelection = if (isChecked) {
                        selectedTypes + "Friend"
                    } else {
                        selectedTypes - "Friend"
                    }
                    onSelection(updatedSelection)
                }
            )
            Text(text = "Friend")

            Checkbox(
                checked = selectedTypes.contains("Family"),
                onCheckedChange = { isChecked ->
                    val updatedSelection = if (isChecked) {
                        selectedTypes + "Family"
                    } else {
                        selectedTypes - "Family"
                    }
                    onSelection(updatedSelection)
                }
            )
            Text(text = "Family")

            Checkbox(
                checked = selectedTypes.contains("Work"),
                onCheckedChange = { isChecked ->
                    val updatedSelection = if (isChecked) {
                        selectedTypes + "Work"
                    } else {
                        selectedTypes - "Work"
                    }
                    onSelection(updatedSelection)
                }
            )
            Text(text = "Work")
        }
    }

    @Composable
    fun RadioButtonSelection(selectedType: String, onSelection: (String) -> Unit) {
        Row {
            RadioButton(
                selected = selectedType == "Friend",
                onClick = { onSelection("Friend") }
            )
            Text(text = "Friend")

            RadioButton(
                selected = selectedType == "Family",
                onClick = { onSelection("Family") }
            )
            Text(text = "Family")

            RadioButton(
                selected = selectedType == "Work",
                onClick = { onSelection("Work") }
            )
            Text(text = "Work")
        }
    }
}
